import { Component } from '@angular/core';
import {AlertController, Platform} from '@ionic/angular';
import {AppAvailability} from '@awesome-cordova-plugins/app-availability/ngx';
import {InAppBrowser} from '@awesome-cordova-plugins/in-app-browser/ngx';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  constructor(public platform: Platform,
              public appAvailability: AppAvailability,
              public inAppBrowser: InAppBrowser,
              public alertController: AlertController) {}

  openFacebook(id) {

    // for Facebook purposes, the page ID is required
    let app;

    if(this.platform.is('ios')) {
      app = 'fb://';

      this.appAvailability.check(app).then(
        (yes: boolean) => {
          console.log(app + ' is available');
          // @ts-ignore
          const browser: InAppBrowser = this.inAppBrowser.create('fb://profile/' + id, '_system');
        },
        (no: boolean) => {
          // @ts-ignore
          const browser: InAppBrowser = this.inAppBrowser.create('https://facebook.com/' + id, '_system');
          console.log(browser);
        }
      );

    } else if(this.platform.is('android')) {
      app = 'com.facebook.katana';

      this.appAvailability.check(app).then(
        (yes: boolean) => {
          console.log(app + ' is available on Android');
          // @ts-ignore
          const browser: InAppBrowser = this.inAppBrowser.create('fb://page/' + id, '_system');
        },
        (no: boolean) => {
          // @ts-ignore
          const browser: InAppBrowser = this.inAppBrowser.create('https://facebook.com/' + id, '_system');
          console.log(browser);
        }
      );

    } else {
      // @ts-ignore
      const browser: InAppBrowser = this.inAppBrowser.create('https://facebook.com/' + name, '_system');
      return;
    }

  }

  openTwitter(name) {
    let app;

    if(this.platform.is('ios')) {
      app = 'twitter://';
    } else if(this.platform.is('android')) {
      app = 'com.twitter.android';
    } else {
      // @ts-ignore
      const browser: InAppBrowser = this.inAppBrowser.create('https://twitter.com/' + name, '_system');
      return;
    }

    this.appAvailability.check(app).then(
      (yes: boolean) => {
        console.log(app + ' is available');
        // @ts-ignore
        const browser: InAppBrowser = this.inAppBrowser.create('twitter://user?screen_name=' + name, '_system');
      },
      (no: boolean) => {
        // @ts-ignore
        const browser: InAppBrowser = this.inAppBrowser.create('https://twitter.com/' + name, '_system');
      }
    );
  }

  openWhatsapp(name) {
    let app;

    if(this.platform.is('ios')) {
      app = 'whatsapp://';
    } else if(this.platform.is('android')) {
      app = 'com.whatsapp';
    } else {
      // @ts-ignore
      const browser: InAppBrowser = this.inAppBrowser.create('https://wa.me/' + name, '_system');
      return;
    }

    this.appAvailability.check(app).then(
      (yes: boolean) => {
        console.log(app + ' is available');
        // @ts-ignore
        const browser: InAppBrowser = this.inAppBrowser.create('whatsapp://send?phone=' + name, '_system');
      },
      (no: boolean) => {
        // @ts-ignore
        const browser: InAppBrowser = this.inAppBrowser.create('https://wa.me/' + name, '_system');
      }
    );
  }

  checkFacebook() {
    let app;
    if(this.platform.is('ios')) {
      app = 'fb://';
    } else if(this.platform.is('android')) {
      app = 'com.facebook.katana';
    }

    this.appAvailability.check(app).then(
      async (yes: boolean) => {
        console.log('Facebook is available');

        const alert = await this.alertController.create({
          header: 'Alert',
          message: 'Facebook is installed',
          buttons: ['OK']
        });

        alert.present();

      },
      async (no: boolean) => {
        const alert = await this.alertController.create({
          header: 'Alert',
          message: 'Facebook is NOT installed',
          buttons: ['OK']
        });

        alert.present();

      }
    );
  }

  checkTwitter() {

    let app;
    if(this.platform.is('ios')) {
      app = 'twitter://';
    } else if(this.platform.is('android')) {
      app = 'com.twitter.android';
    }

    this.appAvailability.check(app).then(
      async (yes: boolean) => {
        console.log('Twitter is available');
        // @ts-ignore
        const alert = await this.alertController.create({
          header: 'Alert',
          message: 'Twitter is installed',
          buttons: ['OK']
        });

        alert.present();

      },
      async (no: boolean) => {
        // @ts-ignore

        const alert = await this.alertController.create({
          header: 'Alert',
          message: 'Twitter is NOT installed',
          buttons: ['OK']
        });

        alert.present();

      }
    );
  }

  checkWhatsapp() {
    let app;
    if(this.platform.is('ios')) {
      app = 'whatsapp://';
    } else if(this.platform.is('android')) {
      app = 'com.whatsapp';
    }

    this.appAvailability.check(app).then(
      async (yes: boolean) => {
        console.log(app + ' is available');
        // @ts-ignore
        const alert = await this.alertController.create({
          header: 'Alert',
          message: 'Whatsapp is installed',
          buttons: ['OK']
        });

        alert.present();
      },
      async (no: boolean) => {
        // @ts-ignore
        const alert = await this.alertController.create({
          header: 'Alert',
          message: 'Whatsapp is NOT installed',
          buttons: ['OK']
        });

        alert.present();
      }
    );
  }


}
