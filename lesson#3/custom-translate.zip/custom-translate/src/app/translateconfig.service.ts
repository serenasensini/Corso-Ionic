import {Injectable} from '@angular/core';
import {Globalization} from '@awesome-cordova-plugins/globalization/ngx';
import {TranslateService} from '@ngx-translate/core';

@Injectable({
  providedIn: 'root'
})
export class TranslateconfigService {

  language: string;

  constructor(public globalization: Globalization, private translate: TranslateService) {
  }

  getDeviceLanguage() {
    this.globalization.getPreferredLanguage().then(res => {
      // this.language = res;
      this.changeLanguage(res);
    });
  }

  getDefaultLanguage() {
    const lang = this.translate.getBrowserLang();
    this.language = lang;
    this.translate.setDefaultLang(lang);
    return lang;
  }

  changeLanguage(lang) {
    this.language = lang;
    this.translate.use(lang);
  }
}
