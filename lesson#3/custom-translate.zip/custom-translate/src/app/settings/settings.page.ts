import { Component, OnInit } from '@angular/core';
import {TranslateconfigService} from '../translateconfig.service';
import {Storage} from '@capacitor/storage';
import {StorageService} from '../storage.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.page.html',
  styleUrls: ['./settings.page.scss'],
})
export class SettingsPage implements OnInit {

  selectedLanguage: any;

  constructor(public translateconfigService: TranslateconfigService,
              private storage: StorageService) {
  }

  ngOnInit() {
  }

  async changeLanguage() {
    console.log(this.selectedLanguage);
    this.translateconfigService.changeLanguage(this.selectedLanguage);

    this.storage.setString('lang', this.selectedLanguage).then(
      () => {
        this.storage.getString('lang').then((data: any) => {
          if (data.value) {
            console.log(data.value);
          }
        });
      }
    );

  }

}
