import { Component } from '@angular/core';
import {TranslateconfigService} from './translateconfig.service';
import {Storage} from '@capacitor/storage';
import {StorageService} from "./storage.service";

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  public appPages = [
    { title: 'Home', url: '/home', icon: 'home' },
    { title: 'Settings', url: '/settings', icon: 'settings' },
  ];

  constructor(public translateconfigService: TranslateconfigService,
              private storage: StorageService) {
    this.checkLang();
  }

  async checkLang() {
    // if language is set, use the stored one...
    this.storage.getString('lang').then((data: any) => {
      if(data.value){
        this.translateconfigService.changeLanguage(data.value);
      } else {
        // ...else use the default one
        const lang = this.translateconfigService.getDefaultLanguage();
        console.log(lang);
        this.translateconfigService.changeLanguage(lang);
      }
    });

  }
}
